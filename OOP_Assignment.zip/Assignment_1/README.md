What you are expected to do:
---------------------------
Go through Test1.txt for the information about your tasks.



