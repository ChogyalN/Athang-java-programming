package com.athang.java.athangJavaFundamental;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AthangJavaFundamentalApplication {

	public static void main(String[] args) {
		SpringApplication.run(AthangJavaFundamentalApplication.class, args);
	}

}
