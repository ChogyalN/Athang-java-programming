package com.athang.java.athangJavaFundamental;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AthangJavaFundamentalApplicationTests {

	@Test
	void contextLoads() {
	}

}
